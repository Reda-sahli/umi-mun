"use client"

import { useLanguage } from "@/components/language-provider"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, MapPin, Clock } from "lucide-react"

export default function EventsPage() {
  const { t } = useLanguage()

  const events = [
    {
      title: "UMI-MUN Annual Conference 2025",
      date: "March 15-17, 2025",
      location: "Moulay Ismail University, Meknes",
      time: "9:00 AM - 6:00 PM",
      description:
        "Our flagship three-day conference simulating United Nations committees and debates on global issues.",
      image: "/placeholder.svg?height=400&width=600",
      registrationLink: "#",
    },
    {
      title: "Regional MUN Workshop",
      date: "November 10, 2024",
      location: "Virtual Event",
      time: "2:00 PM - 5:00 PM",
      description:
        "A preparatory workshop for students interested in participating in Model United Nations conferences.",
      image: "/placeholder.svg?height=400&width=600",
      registrationLink: "#",
    },
    {
      title: "International Relations Seminar",
      date: "January 20, 2025",
      location: "Faculty of Law, Moulay Ismail University",
      time: "10:00 AM - 1:00 PM",
      description: "A seminar on current international relations issues with guest speakers from diplomatic missions.",
      image: "/placeholder.svg?height=400&width=600",
      registrationLink: "#",
    },
    {
      title: "Public Speaking Workshop",
      date: "February 5, 2025",
      location: "Auditorium, Moulay Ismail University",
      time: "3:00 PM - 6:00 PM",
      description:
        "Improve your public speaking skills with this interactive workshop led by experienced MUN delegates.",
      image: "/placeholder.svg?height=400&width=600",
      registrationLink: "#",
    },
  ]

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">{t("events.title")}</h1>

        <div className="space-y-12">
          {events.map((event, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="grid grid-cols-1 md:grid-cols-3">
                  <div className="relative h-64 md:h-auto">
                    <Image src={event.image || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
                  </div>
                  <div className="col-span-2 p-6">
                    <h2 className="text-2xl font-bold mb-3">{event.title}</h2>

                    <div className="flex flex-wrap gap-4 mb-4">
                      <div className="flex items-center text-gray-600 dark:text-gray-400">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center text-gray-600 dark:text-gray-400">
                        <MapPin className="h-4 w-4 mr-2" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center text-gray-600 dark:text-gray-400">
                        <Clock className="h-4 w-4 mr-2" />
                        <span>{event.time}</span>
                      </div>
                    </div>

                    <p className="text-gray-700 dark:text-gray-300 mb-6">{event.description}</p>

                    <Button asChild>
                      <a href={event.registrationLink}>Register Now</a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
