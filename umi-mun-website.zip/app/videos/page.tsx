"use client"

import { useState } from "react"
import { useLanguage } from "@/components/language-provider"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function VideosPage() {
  const { t } = useLanguage()
  const [activeLanguage, setActiveLanguage] = useState<string>("all")

  const videos = [
    {
      id: "video1",
      title: "UMI-MUN Conference Highlights",
      description: "Highlights from our annual conference featuring debates and resolutions.",
      embedId: "dQw4w9WgXcQ", // Example YouTube ID
      language: "en",
    },
    {
      id: "video2",
      title: "Comment participer à UMI-MUN",
      description: "Guide pour les nouveaux participants au Model United Nations.",
      embedId: "dQw4w9WgXcQ", // Example YouTube ID
      language: "fr",
    },
    {
      id: "video3",
      title: "دليل المشاركة في نموذج الأمم المتحدة",
      description: "شرح مفصل لكيفية المشاركة في برنامج نموذج الأمم المتحدة.",
      embedId: "dQw4w9WgXcQ", // Example YouTube ID
      language: "ar",
    },
    {
      id: "video4",
      title: "Public Speaking Workshop",
      description: "Learn effective public speaking techniques for MUN debates.",
      embedId: "dQw4w9WgXcQ", // Example YouTube ID
      language: "en",
    },
    {
      id: "video5",
      title: "Atelier de négociation diplomatique",
      description: "Techniques de négociation pour les délégués du MUN.",
      embedId: "dQw4w9WgXcQ", // Example YouTube ID
      language: "fr",
    },
    {
      id: "video6",
      title: "مهارات الخطابة والإقناع",
      description: "ورشة عمل حول مهارات الخطابة والإقناع في نموذج الأمم المتحدة.",
      embedId: "dQw4w9WgXcQ", // Example YouTube ID
      language: "ar",
    },
  ]

  const filteredVideos = activeLanguage === "all" ? videos : videos.filter((video) => video.language === activeLanguage)

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-8">{t("videos.title")}</h1>

        <div className="flex justify-center mb-12">
          <Tabs defaultValue="all" onValueChange={setActiveLanguage}>
            <TabsList className="grid grid-cols-4 w-[400px]">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="en">🇬🇧 {t("videos.english")}</TabsTrigger>
              <TabsTrigger value="fr">🇫🇷 {t("videos.french")}</TabsTrigger>
              <TabsTrigger value="ar">🇸🇦 {t("videos.arabic")}</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredVideos.map((video) => (
            <Card key={video.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="aspect-video">
                  <iframe
                    width="100%"
                    height="100%"
                    src={`https://www.youtube.com/embed/${video.embedId}`}
                    title={video.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="border-0"
                  ></iframe>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{video.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{video.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredVideos.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-400">No videos available in this language.</p>
          </div>
        )}
      </div>
    </div>
  )
}
